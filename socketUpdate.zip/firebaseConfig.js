// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAPKzJGHdCjEaZd6zr1bM7nAWNFJSU-GbU",
  authDomain: "ummahstar-d55c6.firebaseapp.com",
  projectId: "ummahstar-d55c6",
  storageBucket: "ummahstar-d55c6.firebasestorage.app",
  messagingSenderId: "802124325688",
  appId: "1:802124325688:web:876afa177f8fdcad0bd7cd"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);